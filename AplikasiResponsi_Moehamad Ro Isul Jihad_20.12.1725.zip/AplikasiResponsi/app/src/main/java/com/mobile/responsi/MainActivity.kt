package com.mobile.responsi

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.content.Intent

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // make action into HomeActivity by login button
        val loginButton: Button = findViewById(R.id.login_btn)
        loginButton.setOnClickListener {
            val intentToHome = Intent(this, HomeActivity::class.java)
            startActivity(intentToHome)
        }

        // make action into RecoveryActivity by ForgotPassword button
        val forPassButton: Button = findViewById(R.id.forgotPass_btn)
        forPassButton.setOnClickListener {
            val intentToRecovery = Intent(this, RecoveryActivity::class.java)
            startActivity(intentToRecovery)
        }

        // make action into RegisterActivity by SignUp button
        val signUpButton: Button = findViewById(R.id.signup_btn)
        signUpButton.setOnClickListener {
            val intentToRegister = Intent(this, RegisterActivity::class.java)
            startActivity(intentToRegister)
        }
    }
}