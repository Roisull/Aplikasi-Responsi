package com.mobile.responsi

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.content.Intent

class RegisterActivity : AppCompatActivity() {
    @SuppressLint("WrongViewCast")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        // make action button for back to MainActivity by back button arrow
        val backRegisterButton: Button = findViewById(R.id.back_register_btn)
        backRegisterButton.setOnClickListener {
            val intentToMain = Intent(this, MainActivity::class.java)
            startActivity(intentToMain)
        }

        // make action button for go to Home Activity by register button
        val registerButton: Button = findViewById(R.id.register_btn)
        registerButton.setOnClickListener {
            val intentToHome = Intent(this, HomeActivity::class.java)
            startActivity(intentToHome)
        }
    }
}