package com.mobile.responsi

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.fragment.app.FragmentTransaction

class HomeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        val fragmentHome = HomeFragment
        val fragment = supportFragmentManager.findFragmentByTag(HomeFragment::class.java.simpleName)

        if (fragment !is HomeFragment){
            supportFragmentManager.beginTransaction()
                .add(R.id.action_container, fragmentHome, HomeFragment::class.java.simpleName)
                .commit()
        }
    }

}

private fun Unit.commit() {
    TODO("Not yet implemented")
}

private fun FragmentTransaction.add(actionContainer: Int, fragmentHome: HomeFragment.Companion, simpleName: String) {

}
